# Jira Copy Issue Id + Title

<p align="center">
  <img src="./icons/logo_512.png">
</p>

Makes it possible to copy the issue id + title with one button.
